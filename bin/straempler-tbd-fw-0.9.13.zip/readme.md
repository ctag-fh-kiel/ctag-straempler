# How to flash binaries
See flash.sh