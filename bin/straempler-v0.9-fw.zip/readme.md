## Binary files of app
Use *./flash.sh* for flashing target.
You may update the local binary files by saying *"y"* when asked. If no binary files are found in *../build**, files in local folder are used.